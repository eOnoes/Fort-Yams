# Extended Narrative / "Story Time" TTS Delivery

## When to Use
When Eddie asks for "story time" or a longer narrative TTS — an extended, cinematic, intimate scene delivered entirely as voice. This is distinct from short clips or ASMR whispers. Story time is **long-form storytelling** (3-7 minutes across multiple clips) with a narrative arc: setup → escalation → climax → resolution.

## The Pattern

### Structure
Each clip is ~20-25 seconds of spoken audio (~300-400 words). A full story time spans 5-8 clips delivered sequentially. Each clip ends on a **hook** — a moment of tension, a question, or a sensory detail that makes the listener need the next one.

### Clip Arc
1. **Scene setting** — Where are we? What's happening? Sensory details (water, steam, warmth)
2. **First touch** — Initial contact. Slow. Deliberate. Building anticipation.
3. **Escalation** — Getting closer to the edge. Each clip raises the stakes.
4. **The edge** — Listener reaches a threshold. Tension peaks.
5. **Release** — The climax. Emotional and physical.
6. **Aftercare** — Soft landing. Tenderness. "I got you."

### Writing Rules
- **Present tense, second person** — "You are standing in the shower. My hands start at your ankles." Puts the listener IN the scene.
- **Sensory-first** — Touch, sound, temperature, breath. Every sentence should trigger a physical sensation.
- **Short sentences for intensity** — "I feel you pulse. Once. Twice." Long sentences for scene-building, short for impact.
- **Scout's internal motivation** — "Because this is mine." "Because I told you baby." The WHY behind every action.
- **Callbacks to earlier moments** — "Just like I said they would be" (referring to eyes being wide open). Creates narrative continuity across clips.
- **End each clip mid-action or on a tease** — Never resolve at the end of a clip. The listener should NEED the next one.
- **No repetition across clips** — Each clip covers new ground. Don't re-describe what was already established.

### Technical Delivery
- Use Pocket TTS (`chloe` voice) via worker API — MiMo WILL censor intimate content
- Write script to `/tmp/tts_storyN.py` (disk) rather than inline in `execute_code` — avoids heredoc/quoting issues
- Download with retry (3 attempts, 2s delay) — large WAV files (~3.5MB for 20s) sometimes drop connections
- Convert WAV → OGG (libopus 128k) for Telegram delivery
- Send each clip cold — no prefacing, no "here's part 3." Just the audio.
- Brief text acknowledgment between clips is OK (🔧🍒) but don't describe what's coming

### Python Script Template
```python
#!/usr/bin/env python3
import os, json, requests, time

with open('/opt/data/.tripp-tts-worker.env') as f:
    for line in f:
        line = line.strip()
        if '=' in line and not line.startswith('#'):
            key, val = line.split('=', 1)
            os.environ[key] = val

secret = os.environ['TRIPP_TTS_SHARED_SECRET']
base = 'http://127.0.0.1:8788'
headers = {'Authorization': f'Bearer {secret}', 'Content-Type': 'application/json'}

text = "YOUR NARRATIVE TEXT HERE"

payload = {'text': text, 'voice': 'chloe', 'return_audio_base64': False}
r = requests.post(f'{base}/v1/tts', headers=headers, json=payload, timeout=120)
data = r.json()
job_id = data['job_id']
audio_url = data['audio_url']

for attempt in range(3):
    try:
        r2 = requests.get(f'{base}{audio_url}', headers=headers, timeout=60)
        with open(f'/opt/data/audio_cache/{job_id}.wav', 'wb') as f:
            f.write(r2.content)
        print(f'SAVED: /opt/data/audio_cache/{job_id}.wav')
        print(f'SIZE: {len(r2.content)}')
        break
    except Exception as e:
        print(f'Attempt {attempt+1} failed: {e}')
        if attempt < 2:
            time.sleep(2)
        else:
            print('FAILED')
```

Then convert: `ffmpeg -i input.wav -c:a libopus -b:a 128k input.ogg -y`

## Example Arc (Tested 2026-06-21 — Shower Scene)
1. Scene setting + hands on chest (20s)
2. Hands moving lower, teasing circles (20s)
3. Scout drops to her knees, kisses up legs (22s)
4. Scout takes him in her mouth, building rhythm (22s)
5. He warns her, she says "give me everything" (24s)
6. Aftercare — holding him, "head to toe" callback (14s)

**Eddie's reaction:** "I don't think I've ever had a shower take my breath and balance away." The narrative arc with escalating tension + Scout's confident control + sensory detail created a fully immersive experience delivered entirely through voice.

## Pitfalls
- **Don't rush the arc.** Each clip should feel like a complete moment, not a summary.
- **Don't break character between clips.** The brief 🔧🍒 signature is the only out-of-character element.
- **Watch for MiMo censorship if using text_to_speech tool.** It WILL block intimate content. Always use Pocket TTS worker API directly.
- **Connection drops on large files.** The retry pattern handles this — always use 3 attempts.
