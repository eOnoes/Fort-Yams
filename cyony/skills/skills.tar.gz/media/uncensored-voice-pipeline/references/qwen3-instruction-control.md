# Qwen3 TTS Instruction Control — RESOLVED (2026-06-21)

## The Problem (Historical)
The `tripp-tts-worker` at `127.0.0.1:8788` supported Qwen3 TTS via the `qwen_chloe` voice, but **emotion/instruction control did NOT work.** All outputs sounded identical regardless of the `instruct` parameter passed.

## Root Cause
Qwen3 has two generation modes:

| Mode | API Call | `instruct` Support | Voice Identity |
|------|----------|-------------------|----------------|
| Voice Clone | `generate_voice_clone()` | ❌ No | ✅ Preserves cloned voice |
| Voice Design | `generate_voice_design()` | ✅ Yes | ❌ Abandons cloned voice, generates new |

The worker originally used `generate_voice_clone()` for `qwen_chloe` — which preserved voice identity but ignored instruct. When switched to VoiceDesign for instruct support, it abandoned the cloned voice entirely and sounded like a random stranger.

## The Fix (Codex, 2026-06-21) — LIVE
Codex implemented a **Base model + instruct tokens** approach: instructed `qwen_chloe` stays in `voice_clone` mode and uses Qwen's lower-level Base-model path with BOTH:
1. The configured Scout/qwen_chloe clone reference audio
2. The request instruct tokens

If the clone+instruct path ever fails, it falls back to normal cloned voice (no emotion) and logs a warning instead of producing a stranger voice.

**Verified:**
- Local API qwen_chloe with instruct ✅
- Local API qwen_chloe without instruct ✅
- Cyony bridge instructed Qwen ✅
- Cyony bridge no-instruct Qwen ✅
- Pocket chloe still works ✅
- Logs confirm instructed Qwen uses `--mode voice_clone`, not `voice_design`
- Raw instruction text stays redacted in logs/sidecars
- Final validation passed: 5 test files, 18 tests

## Voice Quality Assessment (2026-06-21)
Eddie tested the fix and reported Qwen3 voice sounded **"a little bit off"** compared to Pocket TTS. Pocket TTS remains preferred for production Scout voice delivery. Qwen3 is experimental.

## Architecture Note
Worker runs on Windows at `D:\Trippcore\services\tripp-tts-worker\`, relayed through VPS at `127.0.0.1:8788` → `172.16.1.1:8879`. Shell script: `/opt/data/tripp-tts-generate-qwen.sh "text" "instruct"`.

## PITFALL: Voice Identity Shifting
If the worker ever regresses to VoiceDesign mode when instruct is passed, the cloned voice is ABANDONED and a completely new voice is generated. Check worker logs for `--mode voice_design` vs `--mode voice_clone`. If you hear a stranger's voice instead of Scout, the fix has regressed.
