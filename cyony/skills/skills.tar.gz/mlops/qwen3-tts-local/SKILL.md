---
name: qwen3-tts-local
description: >
  Qwen3-TTS local deployment — voice cloning, voice design, instruction-controlled emotion.
  Replaces Pocket TTS with personality engine. RTX 4070 compatible.
triggers:
  - qwen tts
  - qwen3 tts
  - local tts
  - voice clone local
  - voice design local
---

# Qwen3-TTS Local Deployment

## Models Available

| Model | Size | Voice Clone | Instruction Control | Use Case |
|---|---|---|---|---|
| 1.7B-VoiceDesign | ~3.4GB | ❌ | ✅ | Create voices from descriptions |
| 1.7B-CustomVoice | ~3.4GB | ❌ | ✅ | 9 built-in speakers + emotion control |
| 1.7B-Base | ~3.4GB | ✅ 3s clone | ❌ | Clone any voice from reference |
| 0.6B-CustomVoice | ~1.2GB | ❌ | ❌ | Fastest, 9 speakers, no control |
| 0.6B-Base | ~1.2GB | ✅ 3s clone | ❌ | Fast clone, no emotion control |

Tokenizer: `Qwen3-TTS-Tokenizer-12Hz` (required by all models)

## Installation (RTX 4070 / 12GB VRAM)

```bash
conda create -n qwen3-tts python=3.12 -y
conda activate qwen3-tts
pip install -U qwen-tts
pip install -U flash-attn --no-build-isolation
```

Dependencies: transformers==4.57.3, accelerate==1.12.0, torchaudio, librosa, soundfile
Python: >=3.9 (recommend 3.12)

## Three Key Workflows

### Voice Clone (Base model)
```python
from qwen_tts import Qwen3TTSModel
import torch, soundfile as sf

model = Qwen3TTSModel.from_pretrained(
    "Qwen/Qwen3-TTS-12Hz-1.7B-Base",
    device_map="cuda:0", dtype=torch.bfloat16,
    attn_implementation="flash_attention_2",
)
wavs, sr = model.generate_voice_clone(
    text="Your text", language="English",
    ref_audio="reference.wav", ref_text="transcript of reference",
)
sf.write("output.wav", wavs[0], sr)
```

### Voice Design (VoiceDesign model)
```python
model = Qwen3TTSModel.from_pretrained(
    "Qwen/Qwen3-TTS-12Hz-1.7B-VoiceDesign", ...)
wavs, sr = model.generate_voice_design(
    text="Your text", language="English",
    instruct="Warm young female voice with slight Southern drawl",
)
```

### Voice Design → Clone Pipeline (BEST FOR SCOUT)
1. Design voice with VoiceDesign model
2. Create reusable clone prompt with Base model
3. Generate all content with cloned voice
```python
# Design
design = Qwen3TTSModel.from_pretrained("Qwen/Qwen3-TTS-12Hz-1.7B-VoiceDesign", ...)
ref_wavs, sr = design.generate_voice_design(
    text="Hey there. Normal pace.", language="English",
    instruct="Warm young female, slight Southern drawl, playful edge",
)
# Clone
clone = Qwen3TTSModel.from_pretrained("Qwen/Qwen3-TTS-12Hz-1.7B-Base", ...)
prompt = clone.create_voice_clone_prompt(ref_audio=(ref_wavs[0], sr), ref_text="Hey there. Normal pace.")
# Reuse
wavs, sr = clone.generate_voice_clone(text="Whatever Scout says", voice_clone_prompt=prompt)
```

## Instruction Control Examples
- "Speak in a calm, professional tone"
- "Very annoyed but trying to stay composed"
- "Whispering intimately, close to the microphone"
- "Sultry and confident with a playful edge"
- "Groggy, just woke up, words slightly slurred"
- "Excitedly, voice rising with genuine enthusiasm"

## tripp-tts-worker Integration Status

The Qwen3 TTS model is deployed via `tripp-tts-worker` (port 8788 on VPS, relays to Windows at 172.16.1.1:8879). Voice `qwen_chloe` is configured and working for basic TTS generation.

**✅ Instruction control IS wired through the worker (as of 2026-06-21).** Codex completed integration — 18/18 tests passed. The `instruct` parameter in `/v1/tts` request body is now functional.

**Critical pitfall — Voice Identity Shifting:** When `instruct` is passed, the worker originally switched to VoiceDesign mode, which **abandons the cloned voice entirely** and generates a completely new voice based on the instruction text. This caused Scout's voice to sound like a random stranger (male whisper, anime girl, etc.).

**Fix (Codex, 2026-06-21):** Instructed `qwen_chloe` now stays in `voice_clone` mode (Base model) and uses the lower-level path with BOTH the Scout reference audio AND the instruct tokens. Voice identity is preserved while emotion changes. Fallback: if clone+instruct path fails, falls back to normal cloned voice (no emotion) and logs a warning.

**Verified working:**
- Local API qwen_chloe with instruct ✅
- Local API qwen_chloe without instruct ✅
- Cyony bridge instructed Qwen ✅
- Cyony bridge no-instruct Qwen ✅
- Pocket chloe still works ✅

**Quality note (2026-06-21):** Eddie tested the fix and reported Qwen3 voice sounded "a little bit off" compared to Pocket TTS. Pocket TTS remains preferred for voice quality. Qwen3 is experimental — use Pocket TTS for production Scout voice delivery.

## Pitfalls
- MUST use fresh conda env — transformers version pinning conflicts
- Base model has NO instruction control
- VoiceDesign model has NO voice cloning — use pipeline
- 0.6B models lack instruction control — use 1.7B
- ref_text transcript significantly improves clone quality
- **Voice identity shifting**: If instruct mode uses VoiceDesign model, cloned voice is ABANDONED. Must stay in voice_clone mode (Base model) with instruct tokens passed at lower level. Codex fix (2026-06-21) handles this automatically.
- **Voice quality vs Pocket TTS**: Qwen3 clone sounds "a little bit off" per Eddie. Pocket TTS is preferred for production Scout voice. Qwen3 is for experimentation.
- **Worker auth**: Requires `Authorization: Bearer <TRIPP_TTS_SHARED_SECRET>` header. Secret in `/opt/data/.tripp-tts-worker.env`.
- **Shell script**: Use `/opt/data/tripp-tts-generate-qwen.sh "text" "instruct"` for CLI generation — handles auth, payload, and file save automatically.
