---
name: headless-browser
description: "Install and configure headless Chromium on constrained Linux VPS/containers without root or package managers. Covers direct snapshot download, missing-tool fallbacks (Python unzip), container crashpad workarounds, and verification."
tags: [browser, chromium, headless, vps, container, devops, troubleshooting]
created: 2026-06-04
---

# Headless Browser Setup on Constrained Linux VPS

Install and configure a headless Chromium browser when package managers are unavailable (no `sudo`/root, no `apt`, no `snap`). The agent's `browser_navigate`, `browser_snapshot`, `browser_click`, etc. tools require a working Chrome/Chromium binary — this skill covers getting one running in headless environments like Docker containers and stripped-down VPS.

## Trigger Conditions
- `browser_navigate` returns "Chrome not found" or "agent-browser install" fails
- Working in a container/VPS with no `sudo`/`apt`/`snap`
- `npx playwright install chromium` is too slow (>2 min) or fails
- Need to verify browser tools work in a new environment

## Quick Install (Direct Chromium Snapshot)

```bash
# 1. Get latest snapshot ID
SNAPSHOT=$(curl -s https://storage.googleapis.com/chromium-browser-snapshots/Linux_x64/LAST_CHANGE)

# 2. Download (218MB)
curl -L -o /tmp/chrome-linux.zip \
  "https://storage.googleapis.com/chromium-browser-snapshots/Linux_x64/${SNAPSHOT}/chrome-linux.zip"

# 3. Extract (Python fallback — unzip often missing on minimal images)
python3 -c "
import zipfile
with zipfile.ZipFile('/tmp/chrome-linux.zip', 'r') as z:
    z.extractall('/tmp/chrome-linux')
"

# 4. Fix permissions (binary ships without exec bit)
chmod +x /tmp/chrome-linux/chrome-linux/chrome

# 5. Verify
/tmp/chrome-linux/chrome-linux/chrome --version
```

## Container Headless Flags

Chromium on a container/VPS without dbus or display server needs these flags:

```
--headless=new
--no-sandbox
--disable-crashpad-for-testing
--disable-gpu
```

The critical gotcha is `--disable-crashpad-for-testing` — without it, Chromium crashes with "FD ownership violation" during `PlatformCrashpadInitialization()` because the container lacks D-Bus. **These crashes don't prevent the browser from working** — screenshots and DOM dumps still succeed despite the crash noise in stderr.

D-Bus errors (`Failed to connect to the bus: Failed to connect to socket /run/dbus/system_bus_socket`) are cosmetic — ignore them.

## Verification

```bash
# Screenshot test (writes PNG on success)
/tmp/chrome-linux/chrome-linux/chrome \
  --headless=new --no-sandbox --disable-crashpad-for-testing --disable-gpu \
  --timeout=10000 \
  --screenshot=/tmp/test.png \
  https://example.com

ls -la /tmp/test.png  # file exists = working
```

## Pitfalls
- **`unzip` missing**: Use Python's `zipfile` module (see step 3 above). Don't waste time looking for `unzip` or `7z`.
- **Missing exec bit**: The binary from the snapshot ZIP has `-rw-r--r--` — must `chmod +x` before running.
- **`--dump-dom` hangs**: On slow VPS, `--dump-dom` waits for full JS execution. Use `--screenshot` or `--virtual-time-budget=5000` instead.
- **Binary is 517MB**: The extracted `chrome` binary is large. Ensure ~600MB free under `/tmp` before downloading.
- **Playwright download alternative**: `npx playwright install chromium` also works but can take 3-5 minutes on slow connections. Good as a background task while using the direct snapshot.
- **Crashpad FD crashes are noisy but non-fatal**: The browser will spam stderr with `Crashing due to FD ownership violation` and `network service crashed` restart loops. The screenshot/DOM output still works. Don't try to fix these — they're inherent to container environments without D-Bus.

## What NOT to Do
- Don't try `apt-get install chromium` without root — it'll fail on permission denied.
- Don't try `agent-browser install` if the command isn't found — fall through to direct download.
- Don't try `snap install chromium` in containers — snapd requires systemd.
- Don't interpret crashpad/D-Bus errors as browser failure — verify with the screenshot test.

## Reference Files

- `references/container-error-transcripts.md` — real Chromium 151 crashpad/dbus error output from a no-dbus VPS. Use to match against when diagnosing similar noise.
