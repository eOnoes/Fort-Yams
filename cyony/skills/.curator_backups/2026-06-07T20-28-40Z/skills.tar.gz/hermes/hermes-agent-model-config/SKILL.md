---
name: hermes-agent-model-config
description: Procedures for selecting and configuring models in Hermes Agent for agentic-style work.
version: 1.0.0
author: Hermes Agent
---

# Hermes Agent Model Configuration and Selection

## Overview
This skill documents how to choose and set the appropriate model for Hermes Agent based on task requirements, especially for agentic workflows involving tool use, delegation, and multi-step reasoning.

## When to Use
- You need to change the default model for better agentic performance.
- You want to configure fallback models for resilience.
- You are optimizing for tool usage, long-context reasoning, or code generation.

## Model Selection Guidelines

### Agentic Workflow Preferences
For tasks involving:
- Tool chaining (web, terminal, file operations)
- Delegation/subagent spawning
- Complex reasoning loops
- Code generation and editing

**Preferred models** (in order of suitability):
1. `qwen/qwen3.7-max` – Strong tool use, 32K context, excellent for agentic loops (OpenRouter).
2. `qwen3.5:397b:cloud` – Ollama Cloud, S-Tier coding, deep code understanding.
3. `minimax-m3:cloud` – Ollama Cloud, A-Tier daily driver, balanced cost/quality.
4. `moonshotai/kimi-k2.6` – Very long context, useful for large file analysis (OpenRouter).

### DeepSeek Models — Direct API ONLY

**HARD RULE:** DeepSeek models (`deepseek-chat`, `deepseek-reasoner`, `deepseek-v4-flash`, `deepseek-v4-pro`) must ALWAYS use the **direct DeepSeek API** — NEVER OpenRouter and NEVER Ollama Cloud.

- **Direct API endpoint:** `https://api.deepseek.com`
- **API key env var:** `DEEPSEEK_API_KEY`
- **Provider type:** OpenAI-compatible (use standard OpenAI adapter, base URL points to deepseek.com)
- **Do not** add DeepSeek to `OPENROUTER_ALLOWED_MODELS`
- **Do not** register DeepSeek with Ollama Cloud
- **Do not** route DeepSeek through any proxy — always direct

This rule was set by Eddie (2026-06-02) to prevent provider routing confusion. If you find yourself about to call DeepSeek through OpenRouter or Ollama, STOP — switch to the direct API.

## Provider Exhaustion Recovery

When the agent goes dark because a provider ran out of credits or hit rate limits:

**Golden rule:** Never route all models through one provider. Diversify so exhaustion of one doesn't kill every path.

**Immediate recovery:** Pick a fallback model from a DIFFERENT provider, switch config, restart container.

Full routing table and recovery procedure → **`references/provider-recovery.md`**

Common causes:
- OpenRouter API dry → fallback to Ollama Cloud or DeepSeek direct
- DeepSeek quota exceeded → fallback to Ollama Cloud
- Ollama Cloud down → fallback to DeepSeek direct

**Prevention:** Keep at least one backup provider configured and tested. DeepSeek models should NEVER be routed through OpenRouter — they have their own direct API that stays independent.

### Configuration Steps
1. Open `/opt/data/config.yaml`.
2. Under the `model:` section, set `default:` to your chosen model ID.
3. Optionally, configure fallback providers in `fallback_providers:` if desired.
4. Save the file.
5. Restart the Hermes Agent container to apply changes:
   ```bash
   docker restart hermes-agent-8eep-hermes-agent-1
   ```
   (Adjust container name as needed.)
6. Verify the change by checking the agent's response or logs.

## Pitfalls
- **Do not set `default:` to a model not in Tripp's approved list** without explicit approval.
- **Changing models mid-session** requires a restart; hot-swapping is not supported.
- **Some models may have different tool-calling formats**; ensure the agent's tool use enforcement is set to `auto` (default).
- **Context window size varies**; verify that your chosen model supports the needed context length for your task.

## Verification
After restart, you can confirm the model is active by:
- Asking the agent to report its model (if exposed via a skill).
- Checking the logs for model initialization messages.
- Observing improved performance on agentic tasks.

## Related Skills
- `hermes-agent` – General Hermes Agent configuration and troubleshooting.
- `model-switching` – For dynamic model selection per task (if implemented).

## References
- See `references/model-comparison.md` for detailed benchmark notes.
- See `templates/config-model.yaml` for a starter configuration snippet.
